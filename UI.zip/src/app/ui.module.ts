import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { TodolistRoutes, TodolistModule } from './todolist/index';
import { DocPubRoutes, DocPubModule } from './docpub/index';
@NgModule({
    declarations: [
    ],
    imports: [
        TodolistModule,
        DocPubModule,
        RouterModule.forChild(TodolistRoutes)
    ],
    providers: []
})
export class UiModule {
}
