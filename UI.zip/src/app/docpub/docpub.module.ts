import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import {DocPubComponent } from './index';

@NgModule({
    declarations: [
        DocPubComponent
    ],
    imports: [
        FormsModule,
        CommonModule
    ],
    exports: [
        DocPubComponent
    ]
})
export class DocPubModule {
}
