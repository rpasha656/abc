import { Component } from '@angular/core';
@Component({
  selector: 'doc-pub',
  templateUrl: 'app/docpub/docpub.component.html',
  styleUrls:['app/docpub/app.component.css']
})
export class DocPubComponent { 
  constructor() {}
  display;
clickHandler(){
	this.display = true;
}
}