import { Routes } from '@angular/router';

import { DocPubComponent } from './docpub.component';

export const DocPubRoutes: Routes = [
  { path: '', component: DocPubComponent }
];
